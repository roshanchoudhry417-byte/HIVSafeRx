export interface PatientRecord {
  id: string;
  timestamp: number;
  name: string;
  age: number;
  weight: number;
  gender: string;
  allergies: string;
  medications: string[];
  interactionCount: { safe: number; warning: number; danger: number };
}

const STORAGE_KEY = "hiv-rx-patient-history";

export function savePatient(record: Omit<PatientRecord, "id" | "timestamp">): PatientRecord {
  const full: PatientRecord = {
    ...record,
    id: crypto.randomUUID(),
    timestamp: Date.now(),
  };
  const history = getHistory();
  history.unshift(full);
  if (history.length > 20) history.pop();
  localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
  return full;
}

export function getHistory(): PatientRecord[] {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  } catch {
    return [];
  }
}

export function clearHistory() {
  localStorage.removeItem(STORAGE_KEY);
}
