export interface Drug {
  id: string;
  name: string;
  category: string;
  isHIV: boolean;
  sideEffects: string[];
  warnings: string[];
  description: string;
}

export interface Interaction {
  drug1: string;
  drug2: string;
  severity: "safe" | "warning" | "danger";
  description: string;
}

export const drugs: Drug[] = [
  {
    id: "efavirenz",
    name: "Efavirenz (EFV)",
    category: "NNRTI",
    isHIV: true,
    sideEffects: ["Dizziness", "Insomnia", "Vivid dreams", "Rash"],
    warnings: ["Avoid in first trimester of pregnancy", "May cause psychiatric symptoms"],
    description: "Non-nucleoside reverse transcriptase inhibitor used in combination ART.",
  },
  {
    id: "tenofovir",
    name: "Tenofovir (TDF)",
    category: "NRTI",
    isHIV: true,
    sideEffects: ["Nausea", "Renal impairment", "Bone density loss"],
    warnings: ["Monitor renal function regularly", "Not recommended with renal impairment"],
    description: "Nucleoside reverse transcriptase inhibitor, backbone of many HIV regimens.",
  },
  {
    id: "dolutegravir",
    name: "Dolutegravir (DTG)",
    category: "INSTI",
    isHIV: true,
    sideEffects: ["Headache", "Insomnia", "Weight gain"],
    warnings: ["Take 2 hours before or 6 hours after antacids"],
    description: "Integrase strand transfer inhibitor, preferred first-line ART.",
  },
  {
    id: "lamivudine",
    name: "Lamivudine (3TC)",
    category: "NRTI",
    isHIV: true,
    sideEffects: ["Headache", "Nausea", "Fatigue"],
    warnings: ["May cause hepatic flares if discontinued in HBV co-infection"],
    description: "Nucleoside analogue reverse transcriptase inhibitor used in combination therapy.",
  },
  {
    id: "ritonavir",
    name: "Ritonavir (RTV)",
    category: "PI Booster",
    isHIV: true,
    sideEffects: ["Nausea", "Diarrhea", "Lipodystrophy", "Hyperlipidemia"],
    warnings: ["Strong CYP3A4 inhibitor — many drug interactions"],
    description: "Used as pharmacokinetic booster for other protease inhibitors.",
  },
  {
    id: "rifampicin",
    name: "Rifampicin",
    category: "Anti-TB",
    isHIV: false,
    sideEffects: ["Hepatotoxicity", "Orange discoloration of fluids", "Nausea"],
    warnings: ["Strong CYP3A4 inducer — reduces efficacy of many drugs"],
    description: "First-line tuberculosis treatment, commonly co-administered with ART.",
  },
  {
    id: "metformin",
    name: "Metformin",
    category: "Antidiabetic",
    isHIV: false,
    sideEffects: ["GI upset", "Lactic acidosis (rare)", "B12 deficiency"],
    warnings: ["Contraindicated in severe renal impairment"],
    description: "First-line treatment for type 2 diabetes mellitus.",
  },
  {
    id: "amlodipine",
    name: "Amlodipine",
    category: "CCB",
    isHIV: false,
    sideEffects: ["Peripheral edema", "Dizziness", "Flushing"],
    warnings: ["Monitor for hypotension"],
    description: "Calcium channel blocker used for hypertension and angina.",
  },
  {
    id: "warfarin",
    name: "Warfarin",
    category: "Anticoagulant",
    isHIV: false,
    sideEffects: ["Bleeding", "Bruising", "Skin necrosis (rare)"],
    warnings: ["Requires INR monitoring", "Many food and drug interactions"],
    description: "Vitamin K antagonist anticoagulant for thromboembolism prevention.",
  },
  {
    id: "fluconazole",
    name: "Fluconazole",
    category: "Antifungal",
    isHIV: false,
    sideEffects: ["Nausea", "Headache", "Hepatotoxicity"],
    warnings: ["CYP2C9 and CYP3A4 inhibitor"],
    description: "Triazole antifungal used for opportunistic infections in HIV patients.",
  },
];

export const interactions: Interaction[] = [
  { drug1: "efavirenz", drug2: "rifampicin", severity: "warning", description: "Rifampicin reduces efavirenz levels by ~25%. May need dose adjustment to 800mg." },
  { drug1: "ritonavir", drug2: "rifampicin", severity: "danger", description: "Rifampicin drastically reduces ritonavir levels. Contraindicated — use rifabutin instead." },
  { drug1: "dolutegravir", drug2: "rifampicin", severity: "warning", description: "Rifampicin reduces dolutegravir levels. Increase DTG to 50mg twice daily." },
  { drug1: "tenofovir", drug2: "metformin", severity: "safe", description: "No significant interaction. Both can be used together safely." },
  { drug1: "ritonavir", drug2: "amlodipine", severity: "warning", description: "Ritonavir increases amlodipine levels. Reduce amlodipine dose and monitor BP." },
  { drug1: "ritonavir", drug2: "warfarin", severity: "danger", description: "Ritonavir significantly alters warfarin metabolism. Close INR monitoring required." },
  { drug1: "efavirenz", drug2: "warfarin", severity: "warning", description: "Efavirenz may reduce warfarin efficacy. Monitor INR closely." },
  { drug1: "fluconazole", drug2: "efavirenz", severity: "warning", description: "Fluconazole increases efavirenz levels. Monitor for CNS side effects." },
  { drug1: "fluconazole", drug2: "warfarin", severity: "danger", description: "Fluconazole significantly increases warfarin effect. High bleeding risk." },
  { drug1: "tenofovir", drug2: "lamivudine", severity: "safe", description: "Standard NRTI backbone combination. Well tolerated together." },
  { drug1: "dolutegravir", drug2: "metformin", severity: "warning", description: "Dolutegravir increases metformin levels. Consider reducing metformin dose." },
  { drug1: "lamivudine", drug2: "metformin", severity: "safe", description: "No clinically significant interaction." },
  { drug1: "dolutegravir", drug2: "tenofovir", severity: "safe", description: "Preferred first-line combination. No significant interaction." },
  { drug1: "dolutegravir", drug2: "lamivudine", severity: "safe", description: "WHO-recommended two-drug regimen. Safe and effective." },
  { drug1: "ritonavir", drug2: "fluconazole", severity: "warning", description: "Mutual CYP inhibition may increase levels of both drugs. Monitor for toxicity." },
];

export function getInteractions(selectedDrugIds: string[]): (Interaction & { drug1Name: string; drug2Name: string })[] {
  const results: (Interaction & { drug1Name: string; drug2Name: string })[] = [];
  for (let i = 0; i < selectedDrugIds.length; i++) {
    for (let j = i + 1; j < selectedDrugIds.length; j++) {
      const a = selectedDrugIds[i];
      const b = selectedDrugIds[j];
      const match = interactions.find(
        (int) => (int.drug1 === a && int.drug2 === b) || (int.drug1 === b && int.drug2 === a)
      );
      if (match) {
        results.push({
          ...match,
          drug1Name: drugs.find((d) => d.id === a)?.name || a,
          drug2Name: drugs.find((d) => d.id === b)?.name || b,
        });
      }
    }
  }
  return results;
}

export function getHIVRecommendations(selectedDrugIds: string[]) {
  const hivDrugs = drugs.filter((d) => d.isHIV);
  return hivDrugs.map((hiv) => {
    const conflicting = selectedDrugIds
      .filter((id) => id !== hiv.id)
      .map((id) => {
        const int = interactions.find(
          (i) => (i.drug1 === hiv.id && i.drug2 === id) || (i.drug1 === id && i.drug2 === hiv.id)
        );
        return int ? { drugId: id, ...int } : null;
      })
      .filter(Boolean);

    const hasDanger = conflicting.some((c) => c?.severity === "danger");
    const hasWarning = conflicting.some((c) => c?.severity === "warning");
    const status: "recommended" | "caution" | "avoid" = hasDanger
      ? "avoid"
      : hasWarning
      ? "caution"
      : "recommended";

    return { drug: hiv, status, conflicts: conflicting };
  });
}
