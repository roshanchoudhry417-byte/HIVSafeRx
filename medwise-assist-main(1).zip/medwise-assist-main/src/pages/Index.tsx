import { useState, useCallback } from "react";
import { motion } from "framer-motion";
import PatientForm from "@/components/PatientForm";
import InteractionDashboard from "@/components/InteractionDashboard";
import RegimenSuggestion from "@/components/RegimenSuggestion";
import ScanMedicine from "@/components/ScanMedicine";
import PatientHistory from "@/components/PatientHistory";
import DownloadReport from "@/components/DownloadReport";
import AISearch from "@/components/AISearch";
import { getInteractions } from "@/data/drugDatabase";
import { savePatient, PatientRecord } from "@/data/patientHistory";
import { Dna, Activity } from "lucide-react";

export default function Index() {
  const [selectedMeds, setSelectedMeds] = useState<string[]>([]);
  const [patientName, setPatientName] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [key, setKey] = useState(0);

  const handleSubmit = useCallback(
    (data: { name: string; age: number; weight: number; gender: string; allergies: string; medications: string[] }) => {
      setPatientName(data.name);
      setSubmitted(true);

      const interactions = getInteractions(data.medications);
      const counts = { safe: 0, warning: 0, danger: 0 };
      interactions.forEach((i) => counts[i.severity]++);

      savePatient({
        name: data.name,
        age: data.age,
        weight: data.weight,
        gender: data.gender,
        allergies: data.allergies,
        medications: data.medications,
        interactionCount: counts,
      });
      setKey((k) => k + 1);
    },
    []
  );

  const handleScanDetect = useCallback(
    (drugId: string) => {
      if (!selectedMeds.includes(drugId)) {
        setSelectedMeds((prev) => [...prev, drugId]);
      }
    },
    [selectedMeds]
  );

  const handleLoadPatient = useCallback((record: PatientRecord) => {
    setSelectedMeds(record.medications);
    setPatientName(record.name);
    setSubmitted(true);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-xl sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-primary/15 flex items-center justify-center">
            <Dna className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="font-mono text-base font-bold text-foreground tracking-tight">
              HIV·RX <span className="text-primary">Interact</span>
            </h1>
            <p className="text-[10px] text-muted-foreground uppercase tracking-widest">
              Drug Interaction Simulator
            </p>
          </div>
          <div className="ml-auto flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-safe" />
            <span className="text-[10px] font-mono text-muted-foreground">System Active</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column — Form & Actions */}
          <div className="lg:col-span-1 space-y-4">
            <PatientForm
              onSubmit={handleSubmit}
              selectedMeds={selectedMeds}
              onMedsChange={setSelectedMeds}
            />
            <ScanMedicine onDetect={handleScanDetect} />
            <DownloadReport patientName={patientName} selectedMeds={selectedMeds} />
            <AISearch />
          </div>

          {/* Right Column — Results */}
          <div className="lg:col-span-2 space-y-6">
            {submitted ? (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <InteractionDashboard selectedMeds={selectedMeds} />
                <RegimenSuggestion selectedMeds={selectedMeds} />
              </motion.div>
            ) : (
              <div className="glass-card p-12 text-center">
                <Dna className="w-16 h-16 mx-auto text-primary/30 mb-4" />
                <h2 className="font-mono text-xl font-semibold text-foreground mb-2">
                  Welcome to HIV·RX Interact
                </h2>
                <p className="text-sm text-muted-foreground max-w-md mx-auto leading-relaxed">
                  Enter patient details and select medications to analyze drug interactions
                  and receive personalized HIV treatment recommendations.
                </p>
              </div>
            )}
            <PatientHistory key={key} onLoad={handleLoadPatient} />
          </div>
        </div>
      </main>
    </div>
  );
}
