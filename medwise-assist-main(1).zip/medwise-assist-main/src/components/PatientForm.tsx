import { useState } from "react";
import { drugs } from "@/data/drugDatabase";
import { motion } from "framer-motion";
import { User, Scale, Heart, AlertTriangle } from "lucide-react";

interface PatientFormProps {
  onSubmit: (data: {
    name: string;
    age: number;
    weight: number;
    gender: string;
    allergies: string;
    medications: string[];
  }) => void;
  selectedMeds: string[];
  onMedsChange: (meds: string[]) => void;
}

export default function PatientForm({ onSubmit, selectedMeds, onMedsChange }: PatientFormProps) {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [weight, setWeight] = useState("");
  const [gender, setGender] = useState("");
  const [allergies, setAllergies] = useState("");

  const toggleMed = (id: string) => {
    onMedsChange(
      selectedMeds.includes(id) ? selectedMeds.filter((m) => m !== id) : [...selectedMeds, id]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !age || !weight || !gender) return;
    onSubmit({
      name,
      age: Number(age),
      weight: Number(weight),
      gender,
      allergies,
      medications: selectedMeds,
    });
  };

  return (
    <motion.form
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      onSubmit={handleSubmit}
      className="glass-card p-6 space-y-5"
    >
      <h2 className="text-lg font-mono font-semibold text-primary flex items-center gap-2">
        <User className="w-5 h-5" /> Patient Profile
      </h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <label className="text-xs font-mono text-muted-foreground uppercase tracking-wider">Full Name</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full bg-secondary border border-border rounded-lg px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary transition"
            placeholder="John Doe"
            required
          />
        </div>
        <div className="space-y-1.5">
          <label className="text-xs font-mono text-muted-foreground uppercase tracking-wider flex items-center gap-1">
            <Scale className="w-3 h-3" /> Age
          </label>
          <input
            type="number"
            value={age}
            onChange={(e) => setAge(e.target.value)}
            className="w-full bg-secondary border border-border rounded-lg px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary transition"
            placeholder="35"
            min={1}
            max={120}
            required
          />
        </div>
        <div className="space-y-1.5">
          <label className="text-xs font-mono text-muted-foreground uppercase tracking-wider">Weight (kg)</label>
          <input
            type="number"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            className="w-full bg-secondary border border-border rounded-lg px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary transition"
            placeholder="70"
            min={1}
            required
          />
        </div>
        <div className="space-y-1.5">
          <label className="text-xs font-mono text-muted-foreground uppercase tracking-wider">Gender</label>
          <select
            value={gender}
            onChange={(e) => setGender(e.target.value)}
            className="w-full bg-secondary border border-border rounded-lg px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary transition"
            required
          >
            <option value="">Select</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
        </div>
      </div>

      <div className="space-y-1.5">
        <label className="text-xs font-mono text-muted-foreground uppercase tracking-wider flex items-center gap-1">
          <AlertTriangle className="w-3 h-3" /> Allergies
        </label>
        <input
          value={allergies}
          onChange={(e) => setAllergies(e.target.value)}
          className="w-full bg-secondary border border-border rounded-lg px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary transition"
          placeholder="e.g. Sulfa, Penicillin"
        />
      </div>

      <div className="space-y-2">
        <label className="text-xs font-mono text-muted-foreground uppercase tracking-wider flex items-center gap-1">
          <Heart className="w-3 h-3" /> Current Medications
        </label>
        <div className="flex flex-wrap gap-2">
          {drugs.map((drug) => (
            <button
              key={drug.id}
              type="button"
              onClick={() => toggleMed(drug.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all duration-200 ${
                selectedMeds.includes(drug.id)
                  ? "bg-primary/20 border-primary/50 text-primary shadow-[0_0_10px_hsl(175_80%_50%/0.15)]"
                  : "bg-secondary border-border text-muted-foreground hover:border-primary/30 hover:text-foreground"
              }`}
            >
              {drug.name}
              <span className="ml-1.5 text-[10px] opacity-60">({drug.category})</span>
            </button>
          ))}
        </div>
      </div>

      <button
        type="submit"
        className="w-full bg-primary text-primary-foreground font-mono font-semibold py-3 rounded-lg hover:opacity-90 transition pulse-glow"
      >
        Analyze Interactions
      </button>
    </motion.form>
  );
}
