import { motion } from "framer-motion";
import { getInteractions } from "@/data/drugDatabase";
import { ShieldCheck, AlertTriangle, ShieldAlert, Activity } from "lucide-react";

const severityConfig = {
  safe: { icon: ShieldCheck, label: "Safe", className: "status-safe border" },
  warning: { icon: AlertTriangle, label: "Warning", className: "status-warning border" },
  danger: { icon: ShieldAlert, label: "Dangerous", className: "status-danger border" },
};

export default function InteractionDashboard({ selectedMeds }: { selectedMeds: string[] }) {
  const results = getInteractions(selectedMeds);

  if (selectedMeds.length < 2) {
    return (
      <div className="glass-card p-6 text-center">
        <Activity className="w-10 h-10 mx-auto text-muted-foreground mb-3 opacity-40" />
        <p className="text-muted-foreground text-sm">Select at least 2 medications to check interactions.</p>
      </div>
    );
  }

  const counts = { safe: 0, warning: 0, danger: 0 };
  results.forEach((r) => counts[r.severity]++);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
      <div className="glass-card p-6">
        <h2 className="text-lg font-mono font-semibold text-primary flex items-center gap-2 mb-4">
          <Activity className="w-5 h-5" /> Interaction Analysis
        </h2>

        <div className="grid grid-cols-3 gap-3 mb-5">
          {(["safe", "warning", "danger"] as const).map((s) => {
            const cfg = severityConfig[s];
            const Icon = cfg.icon;
            return (
              <div key={s} className={`rounded-lg p-3 text-center border ${cfg.className}`}>
                <Icon className="w-5 h-5 mx-auto mb-1" />
                <div className="text-2xl font-mono font-bold">{counts[s]}</div>
                <div className="text-[10px] uppercase tracking-wider opacity-70">{cfg.label}</div>
              </div>
            );
          })}
        </div>

        {results.length === 0 ? (
          <p className="text-center text-muted-foreground text-sm py-4">
            No known interactions between selected medications.
          </p>
        ) : (
          <div className="space-y-3">
            {results.map((r, i) => {
              const cfg = severityConfig[r.severity];
              const Icon = cfg.icon;
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className={`rounded-lg p-4 border ${cfg.className}`}
                >
                  <div className="flex items-start gap-3">
                    <Icon className="w-5 h-5 mt-0.5 shrink-0" />
                    <div className="min-w-0">
                      <div className="font-mono text-sm font-semibold">
                        {r.drug1Name} ↔ {r.drug2Name}
                      </div>
                      <p className="text-xs mt-1 opacity-80 leading-relaxed">{r.description}</p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </motion.div>
  );
}
