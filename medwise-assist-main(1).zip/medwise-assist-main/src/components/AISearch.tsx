import { useState, useCallback, useRef } from "react";
import { Search, Loader2, Sparkles, X } from "lucide-react";
import ReactMarkdown from "react-markdown";

const SEARCH_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/drug-search`;

export default function AISearch() {
  const [query, setQuery] = useState("");
  const [result, setResult] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const abortRef = useRef<AbortController | null>(null);

  const handleSearch = useCallback(async () => {
    const q = query.trim();
    if (!q || isLoading) return;

    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    setIsLoading(true);
    setResult("");
    setError("");

    try {
      const resp = await fetch(SEARCH_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ query: q }),
        signal: controller.signal,
      });

      if (!resp.ok) {
        const errData = await resp.json().catch(() => ({}));
        throw new Error(errData.error || `Request failed (${resp.status})`);
      }

      if (!resp.body) throw new Error("No response stream");

      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let accumulated = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        let newlineIndex: number;
        while ((newlineIndex = buffer.indexOf("\n")) !== -1) {
          let line = buffer.slice(0, newlineIndex);
          buffer = buffer.slice(newlineIndex + 1);
          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (line.startsWith(":") || line.trim() === "") continue;
          if (!line.startsWith("data: ")) continue;

          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") break;

          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content;
            if (content) {
              accumulated += content;
              setResult(accumulated);
            }
          } catch {
            buffer = line + "\n" + buffer;
            break;
          }
        }
      }
    } catch (e: any) {
      if (e.name !== "AbortError") {
        setError(e.message || "Search failed");
      }
    } finally {
      setIsLoading(false);
    }
  }, [query, isLoading]);

  const handleClear = () => {
    abortRef.current?.abort();
    setQuery("");
    setResult("");
    setError("");
    setIsLoading(false);
  };

  return (
    <div className="glass-card p-4 space-y-4">
      <div className="flex items-center gap-2 mb-1">
        <Sparkles className="w-4 h-4 text-primary" />
        <h3 className="font-mono text-sm font-semibold text-foreground">
          AI Drug Search
        </h3>
      </div>

      <div className="flex gap-2">
        <div className="relative flex-1">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            placeholder="e.g. Rifampicin interactions with HIV drugs..."
            className="w-full bg-secondary/60 border border-border/50 rounded-lg px-3 py-2.5 pr-8 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary/50 font-mono"
          />
          {query && (
            <button
              onClick={handleClear}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
        <button
          onClick={handleSearch}
          disabled={isLoading || !query.trim()}
          className="px-4 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-mono font-medium hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 transition-colors"
        >
          {isLoading ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Search className="w-4 h-4" />
          )}
          Search
        </button>
      </div>

      {error && (
        <div className="status-danger border rounded-lg p-3 text-sm">
          {error}
        </div>
      )}

      {result && (
        <div className="bg-secondary/40 border border-border/30 rounded-lg p-4 text-sm text-foreground/90 prose prose-sm prose-invert max-w-none
          prose-headings:font-mono prose-headings:text-foreground prose-headings:text-sm
          prose-strong:text-foreground prose-p:text-foreground/85 prose-li:text-foreground/85
          prose-a:text-primary">
          <ReactMarkdown>{result}</ReactMarkdown>
        </div>
      )}

      {!result && !error && !isLoading && (
        <p className="text-xs text-muted-foreground text-center py-2">
          Search for any drug to get AI-powered interaction analysis for HIV treatment
        </p>
      )}
    </div>
  );
}
