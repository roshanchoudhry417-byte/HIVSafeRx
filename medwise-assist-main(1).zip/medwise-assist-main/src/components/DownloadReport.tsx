import { jsPDF } from "jspdf";
import { drugs, getInteractions } from "@/data/drugDatabase";
import { FileDown } from "lucide-react";

interface ReportProps {
  patientName: string;
  selectedMeds: string[];
}

export default function DownloadReport({ patientName, selectedMeds }: ReportProps) {
  const generate = () => {
    const doc = new jsPDF();
    const interactions = getInteractions(selectedMeds);

    doc.setFontSize(18);
    doc.text("HIV Drug Interaction Report", 20, 25);

    doc.setFontSize(11);
    doc.text(`Patient: ${patientName || "N/A"}`, 20, 38);
    doc.text(`Date: ${new Date().toLocaleDateString()}`, 20, 45);
    doc.text(`Medications: ${selectedMeds.map((id) => drugs.find((d) => d.id === id)?.name).join(", ")}`, 20, 52, { maxWidth: 170 });

    let y = 68;
    doc.setFontSize(14);
    doc.text("Interactions", 20, y);
    y += 10;

    doc.setFontSize(10);
    if (interactions.length === 0) {
      doc.text("No known interactions detected.", 20, y);
    } else {
      interactions.forEach((int) => {
        const sev = int.severity.toUpperCase();
        doc.text(`[${sev}] ${int.drug1Name} <-> ${int.drug2Name}`, 20, y);
        y += 6;
        doc.text(int.description, 25, y, { maxWidth: 165 });
        y += 10;
        if (y > 270) { doc.addPage(); y = 20; }
      });
    }

    doc.save(`hiv-interaction-report-${Date.now()}.pdf`);
  };

  return (
    <button
      onClick={generate}
      disabled={selectedMeds.length < 2}
      className="glass-card p-4 w-full flex items-center gap-3 hover:border-primary/40 transition group disabled:opacity-40 disabled:cursor-not-allowed"
    >
      <div className="w-10 h-10 rounded-lg bg-primary/15 flex items-center justify-center group-hover:bg-primary/25 transition">
        <FileDown className="w-5 h-5 text-primary" />
      </div>
      <div className="text-left">
        <div className="font-mono text-sm font-semibold text-foreground">Download Report</div>
        <div className="text-xs text-muted-foreground">Export PDF interaction analysis</div>
      </div>
    </button>
  );
}
