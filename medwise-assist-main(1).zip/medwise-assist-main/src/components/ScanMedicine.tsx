import { useState, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Camera, X, ScanLine, Pill } from "lucide-react";
import { drugs } from "@/data/drugDatabase";

interface ScanMedicineProps {
  onDetect: (drugId: string) => void;
}

export default function ScanMedicine({ onDetect }: ScanMedicineProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [detected, setDetected] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const startCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setScanning(true);

      // Simulate detection after 3 seconds
      setTimeout(() => {
        const randomDrug = drugs[Math.floor(Math.random() * drugs.length)];
        setDetected(randomDrug.id);
        setScanning(false);
      }, 3000);
    } catch {
      // Camera not available — simulate anyway
      setScanning(true);
      setTimeout(() => {
        const randomDrug = drugs[Math.floor(Math.random() * drugs.length)];
        setDetected(randomDrug.id);
        setScanning(false);
      }, 2000);
    }
  }, []);

  const stopCamera = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setScanning(false);
    setDetected(null);
    setIsOpen(false);
  }, []);

  const handleAdd = () => {
    if (detected) {
      onDetect(detected);
      stopCamera();
    }
  };

  return (
    <>
      <button
        onClick={() => { setIsOpen(true); startCamera(); }}
        className="glass-card p-4 w-full flex items-center gap-3 hover:border-primary/40 transition group"
      >
        <div className="w-10 h-10 rounded-lg bg-primary/15 flex items-center justify-center group-hover:bg-primary/25 transition">
          <Camera className="w-5 h-5 text-primary" />
        </div>
        <div className="text-left">
          <div className="font-mono text-sm font-semibold text-foreground">Scan Medicine</div>
          <div className="text-xs text-muted-foreground">Use camera to identify medication</div>
        </div>
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-background/90 backdrop-blur-md flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="glass-card glow-border w-full max-w-md overflow-hidden"
            >
              <div className="flex items-center justify-between p-4 border-b border-border">
                <h3 className="font-mono font-semibold text-primary flex items-center gap-2">
                  <ScanLine className="w-4 h-4" /> Medicine Scanner
                </h3>
                <button onClick={stopCamera} className="text-muted-foreground hover:text-foreground transition">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="relative aspect-[4/3] bg-secondary">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
                {scanning && (
                  <>
                    <div className="absolute inset-4 border-2 border-primary/40 rounded-lg" />
                    <div className="scan-line" />
                    <div className="absolute bottom-4 left-0 right-0 text-center">
                      <span className="bg-background/80 backdrop-blur px-3 py-1.5 rounded-full text-xs font-mono text-primary">
                        Scanning...
                      </span>
                    </div>
                  </>
                )}
              </div>

              {detected && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 space-y-3"
                >
                  <div className="flex items-center gap-3 p-3 rounded-lg status-safe border">
                    <Pill className="w-5 h-5 shrink-0" />
                    <div>
                      <div className="font-mono text-sm font-semibold">
                        {drugs.find((d) => d.id === detected)?.name}
                      </div>
                      <div className="text-xs opacity-70">Detected via camera scan</div>
                    </div>
                  </div>
                  <button
                    onClick={handleAdd}
                    className="w-full bg-primary text-primary-foreground font-mono font-semibold py-2.5 rounded-lg hover:opacity-90 transition"
                  >
                    Add to Medications
                  </button>
                </motion.div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
