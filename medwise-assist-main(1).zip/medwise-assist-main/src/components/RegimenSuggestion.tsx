import { motion } from "framer-motion";
import { getHIVRecommendations, drugs } from "@/data/drugDatabase";
import { Pill, Check, X, AlertTriangle, Info } from "lucide-react";
import { useState } from "react";

const statusMap = {
  recommended: { label: "Recommended", icon: Check, className: "status-safe border" },
  caution: { label: "Use with Caution", icon: AlertTriangle, className: "status-warning border" },
  avoid: { label: "Avoid", icon: X, className: "status-danger border" },
};

export default function RegimenSuggestion({ selectedMeds }: { selectedMeds: string[] }) {
  const [hoveredDrug, setHoveredDrug] = useState<string | null>(null);
  const nonHIVMeds = selectedMeds.filter((id) => !drugs.find((d) => d.id === id)?.isHIV);
  const recommendations = getHIVRecommendations(nonHIVMeds);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-card p-6">
      <h2 className="text-lg font-mono font-semibold text-primary flex items-center gap-2 mb-4">
        <Pill className="w-5 h-5" /> HIV Regimen Suggestions
      </h2>

      {nonHIVMeds.length === 0 ? (
        <p className="text-muted-foreground text-sm text-center py-4">
          Select non-HIV medications to see compatibility with HIV regimens.
        </p>
      ) : (
        <div className="space-y-3">
          {recommendations.map((rec, i) => {
            const cfg = statusMap[rec.status];
            const Icon = cfg.icon;
            const isHovered = hoveredDrug === rec.drug.id;
            return (
              <motion.div
                key={rec.drug.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.06 }}
                className={`rounded-lg p-4 border cursor-pointer transition-all ${cfg.className}`}
                onMouseEnter={() => setHoveredDrug(rec.drug.id)}
                onMouseLeave={() => setHoveredDrug(null)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="font-mono text-sm font-semibold">{rec.drug.name}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-secondary text-muted-foreground">
                      {rec.drug.category}
                    </span>
                  </div>
                  <span className="text-[10px] uppercase tracking-wider opacity-70">{cfg.label}</span>
                </div>

                {isHovered && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="mt-3 pt-3 border-t border-current/20 space-y-2"
                  >
                    <p className="text-xs opacity-80 flex items-start gap-1.5">
                      <Info className="w-3 h-3 mt-0.5 shrink-0" />
                      {rec.drug.description}
                    </p>
                    <div className="text-xs opacity-70">
                      <strong>Side effects:</strong> {rec.drug.sideEffects.join(", ")}
                    </div>
                    <div className="text-xs opacity-70">
                      <strong>Warnings:</strong> {rec.drug.warnings.join("; ")}
                    </div>
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </div>
      )}
    </motion.div>
  );
}
