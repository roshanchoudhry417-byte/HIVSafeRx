import { motion } from "framer-motion";
import { getHistory, clearHistory, PatientRecord } from "@/data/patientHistory";
import { Clock, Trash2, ShieldCheck, AlertTriangle, ShieldAlert } from "lucide-react";

export default function PatientHistory({ onLoad }: { onLoad?: (record: PatientRecord) => void }) {
  const history = getHistory();

  if (history.length === 0) {
    return (
      <div className="glass-card p-6 text-center">
        <Clock className="w-8 h-8 mx-auto text-muted-foreground mb-2 opacity-40" />
        <p className="text-muted-foreground text-sm">No patient history yet.</p>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-card p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-mono font-semibold text-primary flex items-center gap-2">
          <Clock className="w-5 h-5" /> Patient History
        </h2>
        <button
          onClick={clearHistory}
          className="text-xs text-muted-foreground hover:text-danger transition flex items-center gap-1"
        >
          <Trash2 className="w-3 h-3" /> Clear
        </button>
      </div>

      <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
        {history.map((rec) => (
          <button
            key={rec.id}
            onClick={() => onLoad?.(rec)}
            className="w-full text-left p-3 rounded-lg bg-secondary/50 border border-border hover:border-primary/30 transition"
          >
            <div className="flex items-center justify-between mb-1">
              <span className="font-mono text-sm font-medium text-foreground">{rec.name}</span>
              <span className="text-[10px] text-muted-foreground">
                {new Date(rec.timestamp).toLocaleDateString()}
              </span>
            </div>
            <div className="flex items-center gap-3 text-[10px]">
              <span className="text-safe flex items-center gap-0.5">
                <ShieldCheck className="w-3 h-3" /> {rec.interactionCount.safe}
              </span>
              <span className="text-warning flex items-center gap-0.5">
                <AlertTriangle className="w-3 h-3" /> {rec.interactionCount.warning}
              </span>
              <span className="text-danger flex items-center gap-0.5">
                <ShieldAlert className="w-3 h-3" /> {rec.interactionCount.danger}
              </span>
              <span className="text-muted-foreground ml-auto">
                {rec.medications.length} meds
              </span>
            </div>
          </button>
        ))}
      </div>
    </motion.div>
  );
}
